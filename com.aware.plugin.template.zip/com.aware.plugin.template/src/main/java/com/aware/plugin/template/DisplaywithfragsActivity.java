package com.aware.plugin.template;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;

public class mainActivity extends FragmentActivity {
    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(Bundle savedInstanceState);
        setContentView(R.layout.content_main);
    }
}